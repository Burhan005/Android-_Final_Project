package com.example.languagecourses.model

data class CourseModule(
    val name: String,
//    val description: String
)
