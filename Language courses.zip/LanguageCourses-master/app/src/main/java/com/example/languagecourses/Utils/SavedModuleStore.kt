package com.example.languagecourses.Utils

import com.example.languagecourses.model.CourseModule

object SavedModuleStore {
    val savedModules = mutableListOf<CourseModule>()
}