package com.example.languagecourses.DataClass

import android.widget.VideoView

data class Cprogramming(
    var titleImage: Int,
    var heading: String,
    var desc: String
)
//var desc:String

